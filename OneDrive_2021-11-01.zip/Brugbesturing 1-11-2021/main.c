#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include "servo.h"
#include "h_bridge.h"

#define LEDPIN_GeelBrug1     PC7// pin 30_
#define LEDPIN_GeelBrug2     PC6// pin 31_
#define LEDPIN_RoodBlink1    PC2// pin 35_
#define LEDPIN_RoodBlink2    PC3// pin 34_
#define LEDPIN_GroenBoot1R   PC5// pin 32 *
#define LEDPIN_GroenBoot1L   PC4// pin 33
#define LEDPIN_GroenBoot1B   PC1// pin 36
#define LEDPIN_RoodBoot1R    PC0// pin 37
#define LEDPIN_RoodBoot1L    PD7// pin 38
#define LEDPIN_RoodBoot1B    PG2// pin 39 *

#define LEDPIN_RoodOpen      PA6// pin 28_
#define LEDPIN_RoodDicht     PA7// pin 29_
#define LEDPIN_BlauwOpenen   PA0// pin 22_
#define LEDPIN_BlauwSluiten  PA1// pin 23_
#define LEDPIN_GeelPersoon   PB2// pin 51_
#define LEDPIN_GeelBoot      PB3// pin 50_

#define Ultrasoon_Boot1R     PE0// pin 0,  receiver verander ananloog
#define Ultrasoon_Boot1T     PE1// pin 1,  trigger verander analoog
#define Ultrasoon_Boot2R     PD2// pin 19, receiver
#define Ultrasoon_Boot2T     PD3// pin 18, trigger
#define Ultrasoon_Persoon1R  PH0// pin 17, receiver
#define Ultrasoon_Persoon1T  PH1// pin 16, trigger
#define Ultrasoon_Persoon2R  PJ0// pin 15, receiver
#define Ultrasoon_Persoon2T  PJ1// pin 14, trigger

#define Eindschakelaar_Open  PL1// pin 47 *
#define Eindschakelaar_Dicht PL2// pin 48 *
#define Button_Openen        PL6// pin 43
#define Button_Sluiten       PL5// pin 44
#define Button_Noodstop      PL4// pin 45

#define Geluidssignaal       PE5// pin 3

#define led_aan              PB2// pin 53
#define windsensor           PK0// pin A8


int signaalboot1;
int signaalboot2;
int signaalpersoon;
int windmeter = 0;
int winddrempel = 100;
unsigned long millisec = 0, millisecBlinkLights = 0, millisecWindmeter = 0, millisecPushButton = 0;

void Verlichtingbrugdicht()
{
    PORTC &= ~(1 << LEDPIN_GroenBoot1R); //uit
    PORTC |= (1 << LEDPIN_RoodBoot1R);   //uit
    PORTC &= ~(1 << LEDPIN_GroenBoot1L); //uit
    PORTD |= (1 << LEDPIN_RoodBoot1L);   //uit
    PORTG |= (1 << LEDPIN_RoodBoot1B);  //aan
    PORTC &= ~(1 << LEDPIN_GroenBoot1B);   //aan
    PORTC &= ~(1 << LEDPIN_GeelBrug1);    //uit
    PORTC |= (1 << LEDPIN_GeelBrug2);    //uit
}
void Verlichtingbrugopent1Aan()
{
    PORTC |= (1 << LEDPIN_GroenBoot1R); //uit
    PORTC |= (1 << LEDPIN_RoodBoot1R);   //uit
    PORTC &= ~(1 << LEDPIN_GroenBoot1L); //uit
    PORTD |= (1 << LEDPIN_RoodBoot1L);   //uit
    PORTG &= ~(1 << LEDPIN_RoodBoot1B);  //aan
    PORTC &= ~(1 << LEDPIN_GroenBoot1B);   //aan
    PORTC |= (1 << LEDPIN_GeelBrug1);    //uit
    PORTC |= (1 << LEDPIN_GeelBrug2);    //uit
}
void Verlichtingbrugopent1Uit()
{
    PORTC &= ~(1 << LEDPIN_GroenBoot1R); //uit
    PORTC &= ~(1 << LEDPIN_RoodBoot1R);   //uit
    PORTC &= ~(1 << LEDPIN_GroenBoot1L); //uit
    PORTD &= ~(1 << LEDPIN_RoodBoot1L);   //uit
    PORTG &= ~(1 << LEDPIN_RoodBoot1B);  //aan
    PORTC &= ~(1 << LEDPIN_GroenBoot1B);   //aan
    PORTC &= ~(1 << LEDPIN_GeelBrug1);    //uit
    PORTC &= ~(1 << LEDPIN_GeelBrug2);    //uit
}
void Verlichtingbrugopent2Aan()
{
    PORTC &= ~(1 << LEDPIN_GroenBoot1R); //uit
    PORTC |= (1 << LEDPIN_RoodBoot1R);   //uit
    PORTC |= (1 << LEDPIN_GroenBoot1L); //uit
    PORTD |= (1 << LEDPIN_RoodBoot1L);   //uit
    PORTG &= ~(1 << LEDPIN_RoodBoot1B);  //aan
    PORTC &= ~(1 << LEDPIN_GroenBoot1B);   //aan
    PORTC |= (1 << LEDPIN_GeelBrug1);    //uit
    PORTC |= (1 << LEDPIN_GeelBrug2);    //uit
}
void Verlichtingbrugopent2Uit()
{
    PORTC &= ~(1 << LEDPIN_GroenBoot1R); //uit
    PORTC &= ~(1 << LEDPIN_RoodBoot1R);   //uit
    PORTC &= ~(1 << LEDPIN_GroenBoot1L); //uit
    PORTD &= ~(1 << LEDPIN_RoodBoot1L);   //uit
    PORTG &= ~(1 << LEDPIN_RoodBoot1B);  //aan
    PORTC &= ~(1 << LEDPIN_GroenBoot1B);   //aan
    PORTC |= (1 << LEDPIN_GeelBrug1);    //uit
    PORTC |= (1 << LEDPIN_GeelBrug2);    //uit
}
void Verlichtingbrugopen1Aan()
{
    PORTC |= (1 << LEDPIN_GroenBoot1R); //aan
    PORTC |= (1 << LEDPIN_RoodBoot1R);   //uit
    PORTC |= (1 << LEDPIN_GroenBoot1L); //aan
    PORTD &= ~(1 << LEDPIN_RoodBoot1L);   //uit
    PORTG &= ~(1 << LEDPIN_RoodBoot1B);  //uit
    PORTC |= (1 << LEDPIN_GroenBoot1B);   //aan
    PORTC |= (1 << LEDPIN_GeelBrug1);    //uit
    PORTC |= (1 << LEDPIN_GeelBrug2);    //uit
}
void Verlichtingbrugopen1Uit()
{
    PORTC &= ~(1 << LEDPIN_GroenBoot1R); //aan
    PORTC &= ~(1 << LEDPIN_RoodBoot1R);   //uit
    PORTC &= ~(1 << LEDPIN_GroenBoot1L); //aan
    PORTD &= ~(1 << LEDPIN_RoodBoot1L);   //uit
    PORTG &= ~(1 << LEDPIN_RoodBoot1B);  //uit
    PORTC &= ~(1 << LEDPIN_GroenBoot1B);   //aan
    PORTC |= (1 << LEDPIN_GeelBrug1);    //uit
    PORTC |= (1 << LEDPIN_GeelBrug2);    //uit
}
void Verlichtingbrugopen2Aan()
{
    PORTC |= (1 << LEDPIN_GroenBoot1R); //aan
    PORTC &= ~(1 << LEDPIN_RoodBoot1R);   //uit
    PORTC |= (1 << LEDPIN_GroenBoot1L); //aan
    PORTD |= (1 << LEDPIN_RoodBoot1L);   //uit
    PORTG &= ~(1 << LEDPIN_RoodBoot1B);  //uit
    PORTC |= (1 << LEDPIN_GroenBoot1B);   //aan
    PORTC |= (1 << LEDPIN_GeelBrug1);    //uit
    PORTC |= (1 << LEDPIN_GeelBrug2);    //uit
}
void Verlichtingbrugopen2Uit()
{
    PORTC &= ~(1 << LEDPIN_GroenBoot1R); //aan
    PORTC &= ~(1 << LEDPIN_RoodBoot1R);   //uit
    PORTC &= ~(1 << LEDPIN_GroenBoot1L); //aan
    PORTD &= ~(1 << LEDPIN_RoodBoot1L);   //uit
    PORTG &= ~(1 << LEDPIN_RoodBoot1B);  //uit
    PORTC &= ~(1 << LEDPIN_GroenBoot1B);   //aan
    PORTC |= (1 << LEDPIN_GeelBrug1);    //uit
    PORTC |= (1 << LEDPIN_GeelBrug2);    //uit
}
void VerlichtingbrugsluitAan()
{
    PORTC &= ~(1 << LEDPIN_GroenBoot1R); //uit
    PORTC |= (1 << LEDPIN_RoodBoot1R);   //uit
    PORTC &= ~(1 << LEDPIN_GroenBoot1L); //uit
    PORTD |= (1 << LEDPIN_RoodBoot1L);   //uit
    PORTG &= ~(1 << LEDPIN_RoodBoot1B);  //aan
    PORTC &= ~(1 << LEDPIN_GroenBoot1B);   //uit
    PORTC |= (1 << LEDPIN_GeelBrug1);    //uit
    PORTC |= (1 << LEDPIN_GeelBrug2);    //uit
}
void VerlichtingbrugsluitUit()
{
    PORTC &= ~(1 << LEDPIN_GroenBoot1R); //uit
    PORTC &= ~(1 << LEDPIN_RoodBoot1R);   //uit
    PORTC &= ~(1 << LEDPIN_GroenBoot1L); //uit
    PORTD &= ~(1 << LEDPIN_RoodBoot1L);   //uit
    PORTG &= ~(1 << LEDPIN_RoodBoot1B);  //aan
    PORTC &= ~(1 << LEDPIN_GroenBoot1B);   //uit
    PORTC |= (1 << LEDPIN_GeelBrug1);    //uit
    PORTC |= (1 << LEDPIN_GeelBrug2);    //uit
}

void LedsbedieningpaneelRoodOpenAan()
{PORTA |= (1 << LEDPIN_RoodOpen);}

void LedsbedieningpaneelRoodOpenUit()
{PORTA &= ~(1 << LEDPIN_RoodOpen);}

void LedsbedieningpaneelRoodDichtAan()
{PORTA |= (1 << LEDPIN_RoodDicht);}

void LedsbedieningpaneelRoodDichtUit()
{PORTA &= ~(1 << LEDPIN_RoodDicht);}

void LedsbedieningpaneelBlauwOpenenAan()
{PORTA |= (1 << LEDPIN_BlauwOpenen);}

void LedsbedieningpaneelBlauwOpenenUit()
{PORTA &= ~(1 << LEDPIN_BlauwOpenen);}

void LedsbedieningpaneelBlauwSluitenAan()
{PORTA |= (1 << LEDPIN_BlauwSluiten);}

void LedsbedieningpaneelBlauwSluitenUit()
{PORTA &= ~(1 << LEDPIN_BlauwSluiten);}

void LedsbedieningpaneelGeelBootAan()
{PORTB |= (1 << LEDPIN_GeelBoot);}

void LedsbedieningpaneelGeelBootUit()
{PORTB &= ~(1 << LEDPIN_GeelBoot);}

void LedsbedieningpaneelGeelPersoonAan()
{PORTB |= (1 << LEDPIN_GeelPersoon);}

void LedsbedieningpaneelGeelPersoonUit()
{PORTB &= ~(1 << LEDPIN_GeelPersoon);}

void LedsbedieningpaneelNoodstopAan()
{PORTD |= (1 << led_aan);}

void LedsbedieningpaneelNoodstopUit()
{PORTD &= ~(1 << led_aan);}


void waarschuwingslichten1()
{
            PORTC &= ~(1 << LEDPIN_RoodBlink1);
            PORTC |= (1 << LEDPIN_RoodBlink2);
            _delay_ms(200);
            PORTC |= (1 << LEDPIN_RoodBlink1);
            PORTC &= ~(1 << LEDPIN_RoodBlink2);
            _delay_ms(200);
}

void init()
{
    init_h_bridge();
    init_servo();
}

void informatie()
{       //lees windmeter uit
    if (millisec - millisecWindmeter >= 5000)
    {
    if (ADCH > winddrempel)
    {
      windmeter = 1;
      millisecWindmeter = millisec;
    }
    else
      windmeter = 0;
    }
}

int main(void)
{

    init();

    DDRC |= (1 << LEDPIN_GroenBoot1R);
    DDRC |= (1 << LEDPIN_RoodBoot1R);
    DDRC |= (1 << LEDPIN_GroenBoot1L);
    DDRD |= (1 << LEDPIN_RoodBoot1L);
    DDRG |= (1 << LEDPIN_RoodBoot1B);
    DDRC |= (1 << LEDPIN_GroenBoot1B);
    DDRC |= (1 << LEDPIN_GeelBrug1);
    DDRC |= (1 << LEDPIN_GeelBrug2);
    DDRA |= (1 << LEDPIN_BlauwOpenen);
    DDRA |= (1 << LEDPIN_BlauwSluiten);
    DDRA |= (1 << LEDPIN_RoodOpen);
    DDRA |= (1 << LEDPIN_RoodDicht);
    DDRB |= (1 << LEDPIN_GeelBoot);
    DDRB |= (1 << LEDPIN_GeelPersoon);

    PORTC |= (1 << LEDPIN_GroenBoot1R);
    PORTC |= (1 << LEDPIN_RoodBoot1R);
    PORTC |= (1 << LEDPIN_GroenBoot1L);
    PORTD |= (1 << LEDPIN_RoodBoot1L);
    PORTG |= (1 << LEDPIN_RoodBoot1B);
    PORTC |= (1 << LEDPIN_GroenBoot1B);
    PORTC |= (1 << LEDPIN_GeelBrug1);
    PORTC |= (1 << LEDPIN_GeelBrug2);
    PORTA |= (1 << LEDPIN_BlauwOpenen);
    PORTA |= (1 << LEDPIN_BlauwSluiten);
    PORTA |= (1 << LEDPIN_RoodOpen);
    PORTA |= (1 << LEDPIN_RoodDicht);
    PORTB |= (1 << LEDPIN_GeelBoot);
    PORTB |= (1 << LEDPIN_GeelPersoon);

    DDRL &= ~(1 << Button_Noodstop);
    DDRL &= ~(1 << Button_Openen);
    DDRL &= ~(1 << Button_Sluiten);
    DDRL &= ~(1 << Eindschakelaar_Open);
    DDRL &= ~(1 << Eindschakelaar_Dicht);

    DDRE &= ~(1 << Ultrasoon_Boot1T);
    DDRD &= ~(1 << Ultrasoon_Boot2T);
    DDRH &= ~(1 << Ultrasoon_Persoon1T);
    DDRJ &= ~(1 << Ultrasoon_Persoon2T);

    PORTE |= (1 << Ultrasoon_Boot1R);
    PORTD |= (1 << Ultrasoon_Boot2R);
    PORTH |= (1 << Ultrasoon_Persoon1R);
    PORTJ |= (1 << Ultrasoon_Persoon2R);

    int stand = 1;
    while (1)
    {
         h_bridge_set_percentage(0);
         servo1_set_percentage(80);
         servo2_set_percentage(70);

    switch(stand)
    {
    case 1:
        Verlichtingbrugdicht(); // geen boot
        LedsbedieningpaneelRoodDichtAan();
        LedsbedieningpaneelBlauwOpenenUit();
        LedsbedieningpaneelBlauwSluitenUit();
        LedsbedieningpaneelRoodOpenUit();
        LedsbedieningpaneelGeelPersoonUit();
        LedsbedieningpaneelNoodstopAan();
        LedsbedieningpaneelGeelBootUit();
        signaalboot1 = 1;
        if (signaalboot1 == 1)
        {
            _delay_ms(5000);
            Verlichtingbrugdicht();
            LedsbedieningpaneelRoodDichtAan();
            LedsbedieningpaneelBlauwOpenenUit();
            LedsbedieningpaneelBlauwSluitenUit();
            LedsbedieningpaneelRoodOpenUit();
            LedsbedieningpaneelGeelPersoonUit();
            LedsbedieningpaneelNoodstopAan();
            LedsbedieningpaneelGeelBootAan();
            stand = 2;
        }
        else {stand = 1;}
        break;
    case 2:
        Verlichtingbrugdicht();
        waarschuwingslichten1();
        //waarschuwingslichten2();
        LedsbedieningpaneelRoodDichtAan();
        LedsbedieningpaneelBlauwOpenenUit();
        LedsbedieningpaneelBlauwSluitenUit();
        LedsbedieningpaneelRoodOpenUit();
        LedsbedieningpaneelGeelPersoonUit();
        LedsbedieningpaneelNoodstopAan();
        LedsbedieningpaneelGeelBootAan();
        if (!(PINL & (1 << Button_Openen)))
        {
            stand = 3;
        }
        else {stand = 2;}
        break;
    case 3:
        Verlichtingbrugdicht();
        waarschuwingslichten1();
        LedsbedieningpaneelRoodDichtAan();
        LedsbedieningpaneelBlauwOpenenAan();
        LedsbedieningpaneelBlauwSluitenUit();
        LedsbedieningpaneelRoodOpenUit();
        LedsbedieningpaneelGeelPersoonUit();
        LedsbedieningpaneelNoodstopAan();
        LedsbedieningpaneelGeelBootAan();
        signaalpersoon = 0;
        _delay_ms(3000);
        if (signaalpersoon == 1)
        {
        LedsbedieningpaneelRoodDichtAan();
        LedsbedieningpaneelBlauwOpenenAan();
        LedsbedieningpaneelBlauwSluitenUit();
        LedsbedieningpaneelNoodstopAan();
        LedsbedieningpaneelRoodOpenUit();
        LedsbedieningpaneelGeelBootAan();
        LedsbedieningpaneelGeelPersoonAan();
        stand = 3;
        }
        else
        {   LedsbedieningpaneelRoodDichtAan();
            LedsbedieningpaneelBlauwOpenenAan();
            LedsbedieningpaneelBlauwSluitenUit();
            LedsbedieningpaneelNoodstopAan();
            LedsbedieningpaneelRoodOpenUit();
            LedsbedieningpaneelGeelBootAan();
            LedsbedieningpaneelGeelPersoonUit();
            stand = 4;
        }
        break;
    case 4:
        Verlichtingbrugdicht();
        waarschuwingslichten1();
        LedsbedieningpaneelRoodDichtAan();
        LedsbedieningpaneelBlauwOpenenAan();
        LedsbedieningpaneelBlauwSluitenUit();
        LedsbedieningpaneelRoodOpenUit();
        LedsbedieningpaneelGeelPersoonUit();
        LedsbedieningpaneelNoodstopAan();
        LedsbedieningpaneelGeelBootAan();
        _delay_ms(2000);
        while (stand < 5)
        {
        servo1_set_percentage(-80);
        servo2_set_percentage(-70);
        stand++;
        }
        stand = 5;

        break;
    case 5:
        Verlichtingbrugopent1Aan();
        waarschuwingslichten1();
        LedsbedieningpaneelRoodDichtAan();
        LedsbedieningpaneelBlauwOpenenAan();
        LedsbedieningpaneelBlauwSluitenUit();
        LedsbedieningpaneelRoodOpenUit();
        LedsbedieningpaneelGeelPersoonUit();
        LedsbedieningpaneelNoodstopAan();
        LedsbedieningpaneelGeelBootAan();
        stand = 6;
        break;
    case 6:
        Verlichtingbrugopent1Aan();
        waarschuwingslichten1();
        LedsbedieningpaneelRoodDichtUit();
        LedsbedieningpaneelBlauwOpenenAan();
        LedsbedieningpaneelBlauwSluitenUit();
        LedsbedieningpaneelRoodOpenUit();
        LedsbedieningpaneelGeelPersoonUit();
        LedsbedieningpaneelNoodstopAan();
        LedsbedieningpaneelGeelBootAan();
        windmeter = 0;
        while (stand == 6)
        {
        if ((!(PINL & (1 << Eindschakelaar_Open))) && (windmeter == 0))
        {
            h_bridge_set_percentage(0); stand = 7;
        }
        else {  h_bridge_set_percentage(75);
                stand = 6;}
        }
        stand = 7;
        break;
    case 7:
        Verlichtingbrugopen1Aan();
        waarschuwingslichten1();
        LedsbedieningpaneelRoodDichtUit();
        LedsbedieningpaneelBlauwOpenenUit();
        LedsbedieningpaneelBlauwSluitenUit();
        LedsbedieningpaneelRoodDichtAan();
        LedsbedieningpaneelGeelPersoonUit();
        LedsbedieningpaneelNoodstopAan();
        LedsbedieningpaneelGeelBootAan();
        signaalboot2 = 0;
        if (signaalboot2 == 0)
        {
        waarschuwingslichten1();
        LedsbedieningpaneelRoodDichtUit();
        LedsbedieningpaneelBlauwOpenenUit();
        LedsbedieningpaneelBlauwSluitenUit();
        LedsbedieningpaneelRoodOpenAan();
        LedsbedieningpaneelGeelPersoonUit();
        LedsbedieningpaneelNoodstopAan();
        LedsbedieningpaneelGeelBootUit();
        stand = 8;
        }
        else {stand = 7;}
        break;
    case 8:
        _delay_ms(6000);
        Verlichtingbrugopen1Uit();
        Verlichtingbrugopen2Aan();
        waarschuwingslichten1();
        LedsbedieningpaneelRoodDichtUit();
        LedsbedieningpaneelBlauwOpenenUit();
        LedsbedieningpaneelBlauwSluitenUit();
        LedsbedieningpaneelRoodOpenAan();
        LedsbedieningpaneelGeelPersoonUit();
        LedsbedieningpaneelNoodstopAan();
        LedsbedieningpaneelGeelBootUit();
        while (stand == 8)
        {
        if (!(PINL & (1 << Button_Sluiten)))
        {
        if (!(PINL & (1 << Eindschakelaar_Dicht)))
        {
            h_bridge_set_percentage(0); stand = 9;
        }
        else
        {
        h_bridge_set_percentage(-75);
        VerlichtingbrugsluitAan();
        waarschuwingslichten1();
        LedsbedieningpaneelRoodDichtUit();
        LedsbedieningpaneelBlauwOpenenUit();
        LedsbedieningpaneelBlauwSluitenAan();
        LedsbedieningpaneelRoodOpenAan();
        LedsbedieningpaneelGeelPersoonUit();
        LedsbedieningpaneelNoodstopAan();
        LedsbedieningpaneelGeelBootUit();
        stand = 8;
        }
        }
        }
        stand = 9;
        break;
    case 9:
        VerlichtingbrugsluitAan();
        waarschuwingslichten1();
        LedsbedieningpaneelRoodDichtAan();
        LedsbedieningpaneelBlauwOpenenUit();
        LedsbedieningpaneelBlauwSluitenAan();
        LedsbedieningpaneelRoodOpenUit();
        LedsbedieningpaneelGeelPersoonUit();
        LedsbedieningpaneelNoodstopAan();
        LedsbedieningpaneelGeelBootUit();
        while (stand == 9)
        {
        servo1_set_percentage(80);
        servo2_set_percentage(70);
        }
        _delay_ms(2000);
        PORTC |= (1 << LEDPIN_RoodBlink1);
        PORTC |= (1 << LEDPIN_RoodBlink2);
        Verlichtingbrugdicht();
        stand = 11;
        break;
    case 11:
        Verlichtingbrugdicht();
        LedsbedieningpaneelRoodDichtAan();
        LedsbedieningpaneelBlauwOpenenUit();
        LedsbedieningpaneelBlauwSluitenUit();
        LedsbedieningpaneelRoodOpenUit();
        LedsbedieningpaneelGeelPersoonUit();
        LedsbedieningpaneelNoodstopAan();
        LedsbedieningpaneelGeelBootUit();
        PORTC &= ~(1 << LEDPIN_RoodBlink1);
        PORTC &= ~(1 << LEDPIN_RoodBlink2);
        stand = 1;
        break;
    case 10:
        waarschuwingslichten1();
        LedsbedieningpaneelRoodDichtUit();
        LedsbedieningpaneelBlauwOpenenUit();
        LedsbedieningpaneelBlauwSluitenUit();
        LedsbedieningpaneelRoodOpenUit();
        LedsbedieningpaneelGeelPersoonUit();
        LedsbedieningpaneelNoodstopUit();
        LedsbedieningpaneelGeelBootUit();
        h_bridge_set_percentage(0);
        if (!(PINL & (1 << Button_Openen)))
        {
        stand = 6;
        }
        if (!(PINL & (1 << Button_Sluiten)))
        {
        stand = 8;
        }
      break;
    }
    }
    return (0);
    }
